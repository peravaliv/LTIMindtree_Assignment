package com.example.test;

import com.example.model.Snapshot;
import com.example.service.SnapshotService;
import com.example.service.impl.InMemorySnapshotService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.Instant;
import java.util.*;
import java.util.concurrent.*;

import static org.junit.jupiter.api.Assertions.*;

class ServiceTest {

    private SnapshotService service;

    @BeforeEach
    void setUp() {
        service = new InMemorySnapshotService();
    }

    @Test
    void testBasicPublisherSubscriberFlow() {
        String entityId = "e1";
        Instant now = Instant.now();

        String batchId = service.beginBatch();

        Snapshot snap = new Snapshot(entityId, now, Map.of("key", "value"));
        service.uploadChunk(batchId, List.of(snap));

        assertTrue(service.getSnapshot(entityId).isEmpty(),
                "Snapshot should not be visible before commit");

        service.finalizeBatch(batchId, true);

        Optional<Snapshot> result = service.getSnapshot(entityId);
        assertTrue(result.isPresent());
        assertEquals(now, result.get().getTimestamp());
    }

    @Test
    void testBatchAbort() {
        String batchId = service.beginBatch();
        Snapshot snap = new Snapshot("e2", Instant.now(), Map.of("k", "v"));

        service.uploadChunk(batchId, List.of(snap));
        service.finalizeBatch(batchId, false);

        assertTrue(service.getSnapshot("e2").isEmpty(),
                "Aborted batch data should not be visible");
    }

    @Test
    void testChunkSizeLimit() {
        String batchId = service.beginBatch();
        List<Snapshot> hugeChunk = new ArrayList<>();
        for (int i = 0; i < 1001; i++) {
            hugeChunk.add(new Snapshot("e" + i, Instant.now(), Collections.emptyMap()));
        }

        assertThrows(IllegalArgumentException.class, () -> {
            service.uploadChunk(batchId, hugeChunk);
        });
    }

    @Test
    void testLatestTimestampLogic() {
        String id = "entity1";
        Instant t1 = Instant.now();
        Instant t2 = t1.plusSeconds(10);
        Instant t3 = t1.plusSeconds(5);

        String b1 = service.beginBatch();
        service.uploadChunk(b1, List.of(new Snapshot(id, t1, null)));
        service.finalizeBatch(b1, true);

        String b2 = service.beginBatch();
        service.uploadChunk(b2, List.of(new Snapshot(id, t2, null)));
        service.finalizeBatch(b2, true);

        assertEquals(t2, service.getSnapshot(id).get().getTimestamp());

        String b3 = service.beginBatch();
        service.uploadChunk(b3, List.of(new Snapshot(id, t3, null)));
        service.finalizeBatch(b3, true);

        assertEquals(t2, service.getSnapshot(id).get().getTimestamp());
    }
}
