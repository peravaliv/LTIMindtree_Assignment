package com.example.demo;

import com.example.model.Snapshot;
import com.example.service.SnapshotService;
import com.example.service.impl.InMemorySnapshotService;

import java.time.Instant;
import java.util.Map;
import java.util.List;

public class Main {
    public static void main(String[] args) {

        SnapshotService service = new InMemorySnapshotService();

        // 1. Begin a batch
        String batchId = service.beginBatch();
        System.out.println("Batch started: " + batchId);

        // 2. Create a snapshot
        Snapshot snap = new Snapshot(
                "ENTITY-101",
                Instant.now(),
                Map.of("price", 123.45)
        );

        // 3. Upload into batch
        service.uploadChunk(batchId, List.of(snap));

        // 4. Check BEFORE commit → should be null
        System.out.println("Before commit = " + service.getSnapshot("ENTITY-101"));

        // 5. Commit batch
        service.finalizeBatch(batchId, true);

        // 6. Check AFTER commit → should return snapshot
        System.out.println("After commit = " + service.getSnapshot("ENTITY-101").get());
    }
}
