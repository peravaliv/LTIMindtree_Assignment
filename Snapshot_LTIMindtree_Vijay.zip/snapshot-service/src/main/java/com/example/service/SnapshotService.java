package com.example.service;

import com.example.model.Snapshot;
import java.util.List;
import java.util.Optional;

public interface SnapshotService {

    // Subscriber API
    Optional<Snapshot> getSnapshot(String entityId);

    // Publisher API
    String beginBatch();

    void uploadChunk(String batchId, List<Snapshot> snapshots);

    void finalizeBatch(String batchId, boolean commit);
}
