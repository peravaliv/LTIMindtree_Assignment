package com.example.service.impl;

import com.example.model.Snapshot;
import com.example.service.SnapshotService;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;
/**
 * In-memory implementation of {@link SnapshotService}.
 *
 * <p>
 * The primary design goal of this class is to provide a strongly consistent
 * snapshot store where:
 * <ul>
 *     <li>Publishers upload snapshots in batches</li>
 *     <li>Subscribers always observe a fully committed and atomic view</li>
 *     <li>Uncommitted (in-progress) batches are never exposed</li>
 * </ul>
 *
 * <p>
 * Concurrency Model:
 * <ul>
 *     <li>A global {@link ReadWriteLock} protects the committed snapshot map.</li>
 *     <li>Reads acquire a shared read-lock and are highly concurrent.</li>
 *     <li>Batch commits acquire the write-lock to guarantee atomic visibility.</li>
 * </ul>
 *
 * <p>
 * This implementation prioritizes correctness and simplicity. If the system
 * were to scale significantly, the global write lock could be replaced with
 * sharded locks or a lock-free copy-on-write approach.
 */
public class InMemorySnapshotService implements SnapshotService {

    // Holds latest committed snapshot for each entity
    private final Map<String, Snapshot> globalStore = new ConcurrentHashMap<>();

    //  Holds in-progress batches
    private final Map<String, PendingBatch> activeBatches = new ConcurrentHashMap<>();

    // Read =  non-blocking and  Write = atomic commit
    private final ReadWriteLock rwLock = new ReentrantReadWriteLock();



    // ----****----
    // Subscriber API
    // -----******-----

    @Override
    public Optional<Snapshot> getSnapshot(String entityId) {
        if (entityId == null || entityId.isBlank()) return Optional.empty();

        rwLock.readLock().lock();
        try {
            return Optional.ofNullable(globalStore.get(entityId));
        } finally {
            rwLock.readLock().unlock();
        }
    }

    @Override
    public Map<String, Snapshot> snapshot() {
        rwLock.readLock().lock();
        try {
            return Map.copyOf(globalStore); 
        } finally {
            rwLock.readLock().unlock();
        }
    }



    // ---------------
    // Publisher API
    // --------------

    @Override
    public String beginBatch() {
        String batchId = UUID.randomUUID().toString();
        activeBatches.put(batchId, new PendingBatch(batchId));
        return batchId;
    }

    @Override
    public void uploadChunk(String batchId, List<Snapshot> snapshots) {

        PendingBatch batch = activeBatches.get(batchId);
        if (batch == null) {
            throw new IllegalStateException("Batch not found: " + batchId);
        }

        if (snapshots == null || snapshots.isEmpty()) return;
        if (snapshots.size() > 1000) {
            throw new IllegalArgumentException("Chunk cannot exceed 1000 snapshots");
        }

        for (Snapshot s : snapshots) {
            if (s == null) throw new IllegalArgumentException("Null snapshot inside chunk");
        }

        synchronized (batch) {
            if (batch.isFinalized()) {
                throw new IllegalStateException("Cannot upload to finalized batch: " + batchId);
            }
            batch.addAll(snapshots);
        }
    }

    @Override
    public void finalizeBatch(String batchId, boolean commit) {

        PendingBatch batch = activeBatches.get(batchId);
        if (batch == null) {
            throw new IllegalStateException("Unknown batch: " + batchId);
        }

        synchronized (batch) {
            if (batch.isFinalized()) {
                throw new IllegalStateException("Batch already finalized: " + batchId);
            }
            batch.markFinalized();
        }

        if (commit) {
            applyBatchAtomically(batch);
        }

        activeBatches.remove(batchId);
    }



    // 
    // --- Commit Logic — Atomic per-batch --
    // 

    private void applyBatchAtomically(PendingBatch batch) {

        rwLock.writeLock().lock();
        try {
            for (Snapshot newSnap : batch.getSnapshots()) {

                globalStore.compute(newSnap.getEntityId(), (id, current) -> {
                    if (current == null) return newSnap;

                    // Latest timestamp 
                    if (newSnap.getTimestamp().isAfter(current.getTimestamp())) {
                        return newSnap;
                    }
                    return current;
                });
            }
        } finally {
            rwLock.writeLock().unlock();
        }
    }



    // 
    // ** Internal Batch Representation** 
    // 

    private static class PendingBatch {
        private final String id;
        private final List<Snapshot> snapshots = new ArrayList<>();
        private boolean finalized;

        PendingBatch(String id) {
            this.id = id;
        }

        void addAll(List<Snapshot> snaps) {
            snapshots.addAll(snaps);
        }

        List<Snapshot> getSnapshots() {
            return snapshots;
        }

        boolean isFinalized() {
            return finalized;
        }

        void markFinalized() {
            this.finalized = true;
        }
    }
}
