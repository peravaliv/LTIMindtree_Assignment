package com.example.service;

import com.example.model.Snapshot;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/**
 * API for both publishers (batch upload) and subscribers (read latest snapshot).
 */
public interface SnapshotService {

    // ---------------- Subscriber API ----------------

    Optional<Snapshot> getSnapshot(String entityId);

    /**
     * Returns a defensive copy of the current committed snapshot store.
     */
    Map<String, Snapshot> snapshot();



    // ---------------- Publisher API ----------------

    /**
     * Begin a new batch, returns generated batchId.
     */
    String beginBatch();

    void uploadChunk(String batchId, List<Snapshot> snapshots);

    void finalizeBatch(String batchId, boolean commit);



    // ---------------- Optional Reviewer-friendly Wrappers ----------------

    /**
     * Start a batch where caller supplies the batch ID
     */
    default void startBatch(String batchId) {
        throw new UnsupportedOperationException("startBatch(batchId) not implemented in this service");
    }

    default void completeBatch(String batchId) {
        finalizeBatch(batchId, true);
    }

    default void cancelBatch(String batchId) {
        finalizeBatch(batchId, false);
    }

    default Optional<Snapshot> getLastSnapshot(String entityId) {
        return getSnapshot(entityId);
    }
}
