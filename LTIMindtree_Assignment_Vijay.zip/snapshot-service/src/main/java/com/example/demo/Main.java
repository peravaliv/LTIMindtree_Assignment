package com.example.demo;

import com.example.model.Snapshot;
import com.example.service.SnapshotService;
import com.example.service.impl.InMemorySnapshotService;

import java.time.Instant;
import java.util.Map;
import java.util.List;

public class Main {
    public static void main(String[] args) {

        SnapshotService service = new InMemorySnapshotService();

        String batchId = service.beginBatch();
        System.out.println("Batch started: " + batchId);

        Snapshot snap = new Snapshot(
                "ENTITY-101",
                Instant.now(),
                Map.of("price", 123.45)
        );

        service.uploadChunk(batchId, List.of(snap));

        System.out.println("Before commit = " + service.getSnapshot("ENTITY-101"));

        service.finalizeBatch(batchId, true);

        System.out.println("After commit = " + service.getSnapshot("ENTITY-101").get());
    }
}
