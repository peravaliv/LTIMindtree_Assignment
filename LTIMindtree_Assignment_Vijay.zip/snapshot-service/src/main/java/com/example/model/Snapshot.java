package com.example.model;

import java.time.Instant;
import java.util.Collections;
import java.util.Map;
import java.util.Objects;

/**
 * Represents a snapshot of an entity at a specific point in time.
 * This class is immutable.
 */
public final class Snapshot {
    private final String entityId;
    private final Instant timestamp;
    private final Map<String, Object> data;

    public Snapshot(String entityId, Instant timestamp, Map<String, Object> data) {
        if (entityId == null || entityId.isBlank()) {
            throw new IllegalArgumentException("EntityId cannot be null or empty");
        }
        if (timestamp == null) {
            throw new IllegalArgumentException("Timestamp cannot be null");
        }

        this.entityId = entityId;
        this.timestamp = timestamp;
        this.data = (data == null) ? Collections.emptyMap() : Map.copyOf(data);
    }

    public String getEntityId() {
        return entityId;
    }

    public Instant getTimestamp() {
        return timestamp;
    }

    public Map<String, Object> getData() {
        return data;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Snapshot)) return false;
        Snapshot snapshot = (Snapshot) o;
        return entityId.equals(snapshot.entityId) && timestamp.equals(snapshot.timestamp);
    }

    @Override
    public int hashCode() {
        return Objects.hash(entityId, timestamp);
    }

    @Override
    public String toString() {
        return "Snapshot{" +
                "entityId='" + entityId + '\'' +
                ", timestamp=" + timestamp +
                ", data=" + data +
                '}';
    }
}
